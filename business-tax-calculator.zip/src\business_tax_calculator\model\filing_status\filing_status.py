from abc import ABC

class FilingStatus(ABC):
    pass