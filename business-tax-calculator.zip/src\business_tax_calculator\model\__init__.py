"""
Models package for business data models.
"""
# This file makes the directory a Python package