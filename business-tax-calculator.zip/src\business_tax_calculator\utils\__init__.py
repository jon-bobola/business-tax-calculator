"""
Utilities package for helper functions and configuration.
"""
# This file makes the directory a Python package