from business_tax_calculator.model.filing_status.filing_status import FilingStatus


class SCorporation(FilingStatus):
    pass